# Instrucciones
Se clona el proyecto de la siguiente forma:
``` shell
$ git clone https://github.com/onimenotsuki/fundamentos-de-javascript.git
```
