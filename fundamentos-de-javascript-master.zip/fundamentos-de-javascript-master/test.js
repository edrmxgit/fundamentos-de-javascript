var variableDos = 12;           // Está en desuso
let variable = 11;
const constante = 13 ;

variable = 13;

// constante = 15;
