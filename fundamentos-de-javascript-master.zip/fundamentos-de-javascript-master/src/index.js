// const car = 'Desde archivo car';
// const carDos = 'Car 2';

import car from './car';
