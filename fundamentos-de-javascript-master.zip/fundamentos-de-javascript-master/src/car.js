const car = 'Desde archivo car';

export default car;
